import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins: [react()], build: { outDir: 'dist/client', sourcemap: true }, server: { host: '127.0.0.1' } });
